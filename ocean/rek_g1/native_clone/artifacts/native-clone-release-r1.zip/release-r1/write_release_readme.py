from pathlib import Path
import argparse,hashlib,json

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
for name in ['build','app','tools','run','verification','match']:p.add_argument('--'+name,required=True)
a=p.parse_args();remote='/home/spark-advantage/rek-training/rek-native-clone-20260927-r1'
test=json.loads((root/'remote-result'/a.verification/'summary.json').read_text())
match=json.loads((root/'remote-result'/a.match/'summary.json').read_text())
binary=root/'remote-result'/a.build/'rek-native-clone'
bhash=hashlib.sha256(binary.read_bytes()).hexdigest()
bench=test['benchmark']
scores=', '.join(':'.join(map(str,r['score'])) for r in match['rounds'])
readme=f'''# REK native clone, runnable release

Play: http://127.0.0.1:18771/

The isolated Spark viewer starts paused. Click Play or the arena, then use Daniel's saved G1 controls shown below the view. Escape pauses. New match explicitly resets the fight. A finished native match pauses and keeps its result. The existing official game and older viewers are separate.

This is a working native C++/CUDA clone prototype. It reuses the exported G1 robot meshes, motion clips and original motor-controller weights, with recovered controller, Bot1, referee and fight logic. Full official-game parity remains unverified. The binary targets Spark Linux ARM64 / NVIDIA SM121. It is not a Windows executable.

## Selected, tested implementation

- Spark binary: `{remote}/{a.build}/rek-native-clone`
- Binary SHA256: `{bhash}`
- App: `{remote}/{a.app}`
- Active prepared run: `{remote}/{a.run}`
- Native match mode enabled, continuous direct commands, original 5 s transition and 30 s redo rules.
- CUDA graph stepping disabled: the measured trial diverged numerically and delivered only 1.11x throughput.
- Cold reset reconstructs the scene; counted-body/round resets follow explicitly ordered recovered callbacks.

The release contains real source files, the compiled binary and object receipts, app/assets, build/run/test tooling, and closed verification records. `PUBLICATION.json` pins every release file after NAS readback. External model/library/physics dependencies remain at their verified Spark paths; the sibling `dependency-manifest-r1` inventories their sizes and hashes. This release is reproducible against that preserved host dependency closure, not a fully self-contained redistribution.

## Measured verification

The selected build passed {len(test['checks'])} native integration checks: invalid commands, reset, continuous controls, ownership, round boundaries, original-mesh rendering, and runtime health. Input requests made while a round is inactive are recorded with clone telemetry reason 4 and cannot execute or queue attacks. The app's 28 CPU tests cover controls, serialization, lifecycle and native outcome bookkeeping.

The completed native Bot1-versus-idle test ran {match['final_tick']:,} controller ticks and recorded {len(match['rounds'])} round outcomes and {match['completed_matches']} completed native match. Round scores, idle side first: **{scores}**. The terminal result was {match['final_fight_result']}, winner index {match['final_fight_winner']}, and remained latched for 300 extra ticks. These are clone integration observations, not official-game or learned-policy win rates.

The measured headless benchmark was **{bench['one_arena_control_sps']:.2f} control steps/s per arena**, **{bench['aggregate_arena_control_sps']:.2f} aggregate arena steps/s** across {bench['arenas']} arenas, over {bench['control_ticks']} ticks / {bench['wall_seconds']:.3f} wall seconds. Each control step is 20 ms simulation time with ten 2 ms physics substeps. Rendering was excluded. The manual viewer separately shows measured wall-clock pace and rendering cost; no faster-than-real-time training claim is made.

Original Unity function probes independently verified 27,832 history outputs bit-exactly. Reset/controller tests and the match lifecycle tests are preserved in the sibling original-history, controller-r1 and match-lifecycle-r1 evidence directories. Those checks do not prove whole-game equivalence.

## Data in and data out

| Stage | Recorded data |
|---|---|
| User input | Saved key bindings, held keys, attack edges, release/cancel, input sequence |
| Native command | Forward, strafe and yaw in [-1,1]; move index -1 or 0..16; cancellation |
| Motor execution | Reused motion assets and encoder/decoder weights drive native joint controls |
| Per-step output | Tick, 72 qpos and 70 qvel values, 446 raw observation values, masks, command acceptance/rejection, routes, scores, falls, timers and native fight phase |
| Outcomes | Points per round, round winner/draw/redo/unknown, native match result/winner; unfinished resets counted separately |
| Evidence | Every worker request/reply, UTC and monotonic timing, rendered PNGs with SHA256, recorder health and NAS mirror status |

These recordings originate in the clone. They are kept distinct from the official-game human demonstrations. Rendered frames are sampled; the native protocol records every manually executed controller step. This recorder does not log every contact/force at each 2 ms physics substep.

Spark keeps the source recording at `{remote}/{a.run}`. The live physical-server copy is `R:\\pufferlib\\rek-evidence\\2026-09-27\\rek-native-clone-r1\\live-session-r1`. Immutable frames/configs receive full source/local/NAS hash equality. Growing logs are verified append prefixes until session closure. The passive tunnel and mirror are bounded to four hours per launch; their control/status directory is `C:\\rekagent\\work\\rek-native-clone-20260927-r1\\passive-support-r1\\active`. A `STOP` file there stops those helpers only. The native viewer continues recording on Spark until closed.

## Run and reuse

The selected viewer is already launched; use the link above. To launch a separate fresh viewer after choosing an unused port and a fresh run directory, use the included app `prepare.cjs` and `launch_logged.cjs`. Do not launch twice against the active run.

For a separate headless process on Spark, the following verifies the selected dependency pins and forwards JSON lines on stdin/stdout:

```sh
python3 {remote}/{a.tools}/native_cli.py {remote}/{a.run}
```

Example requests:

```json
{{"id":1,"op":"snapshot"}}
{{"id":2,"op":"step","humanSide":0,"steps":1,"command":{{"forward":0.3,"strafe":-0.7,"yaw":0.2,"moveIndex":4,"cancelAction":false}}}}
{{"id":3,"op":"reset"}}
```

Alternatively, the running viewer exposes `/api/protocol`, `/api/snapshot`, `/api/reset` and `/api/step`. Explicit stepping requires a paused viewer and is serialized against human play. Mode changes between categorical and direct control require a reset. Do not start a competing GPU workload during human evaluation.

The included `tools/build-native.sh` accepts `REK_CLONE_SOURCE_DIR` and `REK_CLONE_BUILD_DIR`; the output build directory must be fresh. It checks every reused object hash, recompiles the changed native units, links against the inventoried Spark dependencies and writes binary/object hashes. Read the dependency manifest before relocating the build.

## Known parity limits

Authoritative server physics, complete initialization state and global Unity callback subscription order are not yet verified. The chosen reset callback order is explicit, not proven. Four of twenty heading probes differed by one FP32 ULP. The full physics backend is native MuJoCo GPU; no end-to-end official state/action trajectory equivalence has been demonstrated. Bot1 uses candidate RNG/update cadence. Motor shutdown is unmodeled; current local G1 get-up clips are null. The presentation countdown is omitted because its original Timeline duration is unrecovered. Original Unity shaders/materials and visual identity are incomplete. The renderer still reports an OpenGL 0x502 setup warning on stderr, although actual PNG decode and visual inspection succeeded. Observable-policy joint correspondence is unproven; raw state remains available.

The earlier GPU match test let the idle participant win through Bot1 falls. Final results above must be interpreted as implementation checks; they do not establish useful Bot1 skill or official behavioral parity. Full parity requires matched initial states and command traces from the official app, including contact/scoring/reset outcomes, with declared tolerances and independent held-out cases.
'''
(root/'README.md').write_text(readme,encoding='utf-8')
print('Wrote release README from verified artifacts')
