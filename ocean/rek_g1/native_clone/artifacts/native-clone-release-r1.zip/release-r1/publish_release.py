"""Publish an immutable release and verify every copied byte on physical NAS."""
from pathlib import Path
import argparse,datetime,hashlib,json,shutil

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--build',required=True);p.add_argument('--app',required=True)
    p.add_argument('--tools',required=True);p.add_argument('--run',required=True)
    p.add_argument('--verification',required=True);p.add_argument('--match',required=True)
    args=p.parse_args();root=Path(__file__).resolve().parent
    destination=Path(r'R:\pufferlib\rek-evidence\2026-09-27\rek-native-clone-r1\release-r1')
    if destination.exists():raise FileExistsError('Fresh release required')
    for child in [args.verification,args.match]:
        summary=json.loads((root/'remote-result'/child/'summary.json').read_text())
        if summary.get('ok') is not True:raise RuntimeError('Verification did not pass: '+child)
    match=json.loads((root/'remote-result'/args.match/'summary.json').read_text())
    if match.get('completed_matches',0)<1:raise RuntimeError('No verified native match')
    destination.mkdir(parents=True)
    sources={
        'source':root/'source', 'app':root/args.app,'tools':root/args.tools,
        'build':root/'remote-result'/args.build,
        'verification':root/'remote-result'/args.verification,
        'match-verification':root/'remote-result'/args.match,
        'prepared-run':root/'remote-result'/args.run,
        'passive-support':root/'passive-support-r1',
        'live-verification':root/'live-verification-r1',
        'cli-verification':root/'remote-result'/'cli-verification-r1',
        'dependencies':root/'dependency-manifest-r1',
    }
    records=[]
    def copy(source,relative):
        target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
        before=digest(source)
        with target.open('xb') as out,source.open('rb') as inp:shutil.copyfileobj(inp,out)
        after=digest(target)
        if after!=before or digest(source)!=before:raise RuntimeError('Copy changed: '+str(source))
        records.append(dict(path=relative,bytes=target.stat().st_size,sha256=after,source=str(source)))
    for label,source in sources.items():
        for path in sorted(source.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and 'active' not in path.relative_to(source).parts:
                copy(path,label+'/'+path.relative_to(source).as_posix())
    for name in ['README.md','native_cli.py','remote_task.py','fetch_closed.py','publish_release.py','start_passive.ps1','verify_live.py','write_release_readme.py']:
        copy(root/name,name)
    manifest=dict(schema='rek.native_clone.release.v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        selected_build=args.build,selected_app=args.app,selected_run=args.run,
        full_official_parity_proven=False,source_and_NAS_hashes_equal=True,files=records)
    target=destination/'PUBLICATION.json';target.write_text(json.dumps(manifest,indent=2)+'\n')
    (root/'RELEASE-PUBLISHED.json').write_text(json.dumps({'destination':str(destination),'files':len(records),
        'bytes':sum(f['bytes'] for f in records),'manifest_sha256':digest(target)},indent=2)+'\n')
    print((root/'RELEASE-PUBLISHED.json').read_text())
if __name__=='__main__':main()
