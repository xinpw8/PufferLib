from pathlib import Path
import datetime,hashlib,json,time,urllib.request
from remote_task import connect,REMOTE

root=Path(__file__).resolve().parent
out=root/'live-verification-r1';out.mkdir(exist_ok=True)
assert not any(out.iterdir()), 'Fresh verification output required'
control=root/'passive-support-r1/active'
nas=Path(r'R:\pufferlib\rek-evidence\2026-09-27\rek-native-clone-r1\live-session-r1')
local_mirror=json.loads((control/'mirror-status.json').read_text())
assert local_mirror['phase'] in ['watching','copying'] and not local_mirror['errors']
mirror=json.loads((nas/'mirror-status.json').read_text())
tunnel=json.loads((control/'tunnel-status.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc)
for record in [mirror,tunnel]:
    assert (now-datetime.datetime.fromisoformat(record['utc'])).total_seconds()<15
    assert not record['errors'],record
assert mirror['phase']=='watching' and tunnel['phase']=='listening'
health=mirror['source_recorder_health'];assert health['ok'] and not health['recorderFailure'] and not health['workerFailure']
assert (now-datetime.datetime.fromisoformat(health['utc'].replace('Z','+00:00'))).total_seconds()<15
def get(path):
    with urllib.request.urlopen('http://127.0.0.1:18771'+path,timeout=10) as response:return response.read()
state=json.loads(get('/api/snapshot'));assert state['ok'] and state['paused'] and state['tick']==0 and state['failureBits']==0
protocol=json.loads(get('/api/protocol'));assert protocol['schema']=='rek.native_clone.step.v1'
png=get('/frame.png');assert png[:8]==b'\x89PNG\r\n\x1a\n'
pngsha=hashlib.sha256(png).hexdigest()
inventory=json.loads((nas/'inventory.json').read_text())['files'];frame=inventory['frames/00000001.png']
assert frame['source_local_nas_sha_equal'] and frame['sha256']==pngsha
assert hashlib.sha256((nas/'frames/00000001.png').read_bytes()).hexdigest()==pngsha
with connect() as client,client.open_sftp() as sftp:
    def read(path):
        with sftp.open(path,'rb') as stream:return stream.read()
    started=json.loads(read(REMOTE+'/run-r4/STARTED.json'))
    pid=started['process']['pid'];ticks=read('/proc/%s/stat'%pid).decode().split(') ')[1].split()[19]
    assert ticks==started['process']['start_ticks'] and pid==health['pid']
    children=read('/proc/%s/task/%s/children'%(pid,pid)).decode().split()
    assert len(children)==1,children
    child=children[0];childcmd=read('/proc/'+child+'/cmdline').decode().split('\0')
    assert childcmd[0]==REMOTE+'/build-r6/rek-native-clone',childcmd
    childstat=read('/proc/'+child+'/stat').decode().split(') ')[1].split()[19]
    assert hashlib.sha256(read(REMOTE+'/run-r4/frames/00000001.png')).hexdigest()==pngsha
    (out/'STARTED.json').write_text(json.dumps(started,indent=2)+'\n')
summary={'ok':True,'utc':now.isoformat(),'url':'http://127.0.0.1:18771/',
    'server_pid':pid,'server_start_ticks':ticks,'worker_pid':int(child),'worker_start_ticks':childstat,
    'state_tick':state['tick'],'paused':state['paused'],'protocol':protocol,'frame_sha256':pngsha,
    'frame_source_NAS_HTTP_sha_equal':True,'mirror':mirror,'local_mirror':local_mirror,'tunnel':tunnel,
    'recording_has_gameplay':False,'scope':'read-only startup and point-in-time backup verification'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'preview.png').write_bytes(png)
print(json.dumps({k:v for k,v in summary.items() if k not in ['mirror','tunnel','protocol']}))
