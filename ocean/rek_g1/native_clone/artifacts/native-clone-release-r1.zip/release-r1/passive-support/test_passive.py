import io,json,os,sys,tempfile,unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch
import passive as p

class RemoteFile:
    def __init__(self,path):self.path=path;self.f=path.open('rb')
    def read(self,n):return self.f.read(n)
    def seek(self,n):return self.f.seek(n)
    def stat(self):return self.path.stat()
    def __enter__(self):return self
    def __exit__(self,*args):self.f.close()
class Sftp:
    def __init__(self,path):self.path=path
    def open(self,*args):return RemoteFile(self.path)
class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='clone-passive-test-');self.root=Path(self.temp.name).resolve()
    def tearDown(self):
        assert self.root.name.startswith('clone-passive-test-')
        self.temp.cleanup()
    def test_append_resume_and_tail_guard(self):
        dest=self.root/'stream';src=io.BytesIO(b'a'*70000)
        r=p.append_file(src,dest,70000,lambda:False);self.assertEqual(r['added_bytes'],70000)
        src=io.BytesIO(b'a'*70000+b'new\n')
        r=p.append_file(src,dest,70004,lambda:False);self.assertEqual(r['added_bytes'],4);self.assertEqual(dest.read_bytes(),src.getvalue())
        before=dest.read_bytes()
        with self.assertRaisesRegex(IOError,'prefix'):p.append_file(io.BytesIO(b'a'*69999+b'bnew\nmore'),dest,70008,lambda:False)
        self.assertEqual(dest.read_bytes(),before)
        with self.assertRaisesRegex(IOError,'truncated'):p.append_file(io.BytesIO(b'a'),dest,1,lambda:False)
        self.assertEqual(dest.read_bytes(),before)
    def test_interrupted_partial_resumes_without_duplicate(self):
        data=b'x'*(p.CHUNK+128);dest=self.root/'stream';calls=0
        def stop():
            nonlocal calls
            calls+=1;return calls>1
        with self.assertRaises(InterruptedError):p.append_file(io.BytesIO(data),dest,len(data),stop)
        self.assertEqual(dest.stat().st_size,p.CHUNK)
        p.append_file(io.BytesIO(data),dest,len(data),lambda:False)
        self.assertEqual(dest.read_bytes(),data)
    def test_immutable_full_source_local_nas_hash_and_conflict(self):
        source=self.root/'source.json';source.write_text('{"n":1}')
        local=self.root/'local.json';nas=self.root/'nas.json'
        r=p.immutable_file(Sftp(source),'remote',local,nas,lambda:False)
        self.assertEqual(r['sha256'],p.sha(source));self.assertEqual(p.sha(local),p.sha(nas))
        source.write_text('{"n":2}')
        with self.assertRaisesRegex(IOError,'differs'):p.immutable_file(Sftp(source),'remote',local,nas,lambda:False)
        self.assertEqual(nas.read_text(),'{"n":1}')
    def test_incomplete_png_is_not_published(self):
        source=self.root/'source';source.write_bytes(b'\x89PNG\r\n\x1a\n'+b'0'*30)
        with self.assertRaisesRegex(IOError,'footer'):p.immutable_file(Sftp(source),'remote',self.root/'local.png',self.root/'nas.png',lambda:False)
        self.assertFalse((self.root/'nas.png').exists())
    def test_scoped_paths_and_fresh_identity(self):
        for name in ['../x','/x','a/../../b',r'..\x','a:b']:
            with self.assertRaises(ValueError):p.scoped(self.root,name)
        self.assertEqual(p.scoped(self.root,'frames/1.png'),self.root/'frames/1.png')
        local=self.root/'spool';nas=self.root/'nas';identity=p.initialize(local,nas,False)
        self.assertEqual(p.initialize(local,nas,True),identity)
        with self.assertRaises(FileExistsError):p.initialize(local,nas,False)
        wrong=json.loads((nas/'MIRROR-IDENTITY.json').read_text());wrong['id']='different';p.atomic(nas/'MIRROR-IDENTITY.json',wrong)
        with self.assertRaisesRegex(RuntimeError,'identity'):p.initialize(local,nas,True)
    def test_stop_prevents_any_connection(self):
        (self.root/'STOP').write_text('stop')
        for mode in ['tunnel','mirror']:
            with patch.object(sys,'argv',['passive.py',mode,'--local',str(self.root)]),patch.object(p,'connect') as connect:
                with self.assertRaisesRegex(RuntimeError,'STOP'):p.main()
                connect.assert_not_called()
    def test_singleton_is_exclusive_and_released_on_exit(self):
        path=self.root/'owned.lock'
        with p.OwnedLock(path):
            with self.assertRaises(OSError):
                with p.OwnedLock(path):pass
        with p.OwnedLock(path):pass
    def test_stop_during_mirror_retries_is_published_to_owned_nas(self):
        control=self.root/'control';control.mkdir();nas=self.root/'nas'
        def unavailable():
            (control/'STOP').write_text('stop');raise OSError('synthetic disconnected SSH')
        with patch.object(p,'connect',side_effect=unavailable):
            p.mirror(SimpleNamespace(local=control,nas=nas,resume=False,minutes=1))
        local_status=json.loads((control/'mirror-status.json').read_text())
        self.assertEqual(local_status['phase'],'stopped');self.assertEqual(local_status['reason'],'STOP')
        self.assertEqual(json.loads((nas/'mirror-status.json').read_text()),local_status)
if __name__=='__main__':unittest.main(verbosity=2)
