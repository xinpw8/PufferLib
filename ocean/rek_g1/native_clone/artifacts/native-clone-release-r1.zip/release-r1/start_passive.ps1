$ErrorActionPreference='Stop'
$taskRoot='C:\rekagent\work\rek-native-clone-20260927-r1'
$taskScript=Join-Path $taskRoot 'passive-support-r1\passive.py'
$taskControl=Join-Path $taskRoot 'passive-support-r1\active'
$taskRemote='/home/spark-advantage/rek-training/rek-native-clone-20260927-r1/run-r4'
if(Test-Path -LiteralPath $taskControl){throw 'Fresh passive control directory required'}
if(Get-NetTCPConnection -LocalPort 18771 -State Listen -ErrorAction SilentlyContinue){throw 'Local viewer port occupied; preserving existing listener'}
New-Item -ItemType Directory -Path $taskControl | Out-Null
$taskProcesses=@()
foreach($taskMode in @('tunnel','mirror')){
    $taskArgs=@($taskScript,$taskMode,'--local',$taskControl,'--remote',$taskRemote,'--minutes','240')
    $taskProcess=Start-Process -WindowStyle Hidden -FilePath 'C:\Python312\python.exe' -ArgumentList $taskArgs -PassThru -RedirectStandardOutput (Join-Path $taskControl "$taskMode.stdout.log") -RedirectStandardError (Join-Path $taskControl "$taskMode.stderr.log")
    $taskProcesses += [ordered]@{mode=$taskMode;pid=$taskProcess.Id;startedUtc=$taskProcess.StartTime.ToUniversalTime().ToString('o');args=$taskArgs}
}
$taskReceipt=[ordered]@{utc=(Get-Date).ToUniversalTime().ToString('o');scriptSha256=(Get-FileHash -LiteralPath $taskScript -Algorithm SHA256).Hash.ToLower();maximumMinutes=240;processes=$taskProcesses}
$taskReceipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskControl 'STARTED.json') -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 6
