"""Hash-verified fetch of a closed task-owned remote directory."""
from pathlib import Path
import argparse,hashlib,json,stat
from remote_task import connect,REMOTE,LOCAL

def main():
    p=argparse.ArgumentParser();p.add_argument('child');a=p.parse_args()
    assert a.child not in ('','.','..') and '/' not in a.child and '\\' not in a.child
    dest=LOCAL/'remote-result'/a.child;dest.mkdir(parents=True,exist_ok=False);records=[]
    with connect() as client,client.open_sftp() as sftp:
        def fetch(remote,local):
            for entry in sftp.listdir_attr(remote):
                source=remote+'/'+entry.filename;target=local/entry.filename
                if stat.S_ISDIR(entry.st_mode):target.mkdir();fetch(source,target)
                elif stat.S_ISREG(entry.st_mode):
                    with sftp.open(source,'rb') as f:data=f.read()
                    digest=hashlib.sha256(data).hexdigest()
                    with target.open('xb') as f:f.write(data)
                    assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
                    with sftp.open(source,'rb') as f:assert hashlib.sha256(f.read()).hexdigest()==digest
                    records.append(dict(path=target.relative_to(dest).as_posix(),bytes=len(data),sha256=digest))
                else:raise ValueError('Unsupported remote entry '+source)
        fetch(REMOTE+'/'+a.child,dest)
    (dest/'FETCHED.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({'directory':str(dest),'files':len(records),'bytes':sum(r['bytes'] for r in records)}))

if __name__=='__main__':main()
