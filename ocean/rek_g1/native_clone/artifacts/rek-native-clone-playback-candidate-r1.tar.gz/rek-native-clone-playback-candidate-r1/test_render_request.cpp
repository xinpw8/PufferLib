#include "eval_render_request.h"
#include <cassert>
#include <cstring>
#include <iostream>
#include <limits>
#include <memory>
using Json=std::unique_ptr<cJSON,decltype(&cJSON_Delete)>;
int checks=0;
Json valid(){
    Json j(cJSON_CreateObject(),cJSON_Delete);cJSON_AddStringToObject(j.get(),"op","frame");
    auto* q=cJSON_AddArrayToObject(j.get(),"qpos");
    for(int i=0;i<72;i++)cJSON_AddItemToArray(q,cJSON_CreateNumber((i-36)*.03125));
    return j;
}
void reject(cJSON* j){bool caught=false;try{rek_eval::frame_request(j);}catch(const std::runtime_error&){caught=true;}assert(caught);checks++;}
int main(){
    {auto j=valid();auto r=rek_eval::frame_request(j.get());assert(!r.has_tick&&!r.has_generation);checks++;
        for(int i=0;i<72;i++){assert(r.qpos[i]==float((i-36)*.03125));checks++;}}
    {auto j=valid();cJSON_AddNumberToObject(j.get(),"snapshotTick",9007199254740991.0);cJSON_AddNumberToObject(j.get(),"generation",0);
        auto r=rek_eval::frame_request(j.get());assert(r.has_tick&&r.has_generation&&r.tick==9007199254740991.0&&r.generation==0);checks++;}
    for(auto op:{"step","reset","policy","snapshot"}){auto j=valid();cJSON_ReplaceItemInObjectCaseSensitive(j.get(),"op",cJSON_CreateString(op));reject(j.get());}
    for(int n:{0,71,73}){auto j=valid();auto*q=cJSON_CreateArray();for(int i=0;i<n;i++)cJSON_AddItemToArray(q,cJSON_CreateNumber(0));cJSON_ReplaceItemInObjectCaseSensitive(j.get(),"qpos",q);reject(j.get());}
    for(auto value:{std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN(),1e300,-1e300}){
        auto j=valid();cJSON_ReplaceItemInArray(cJSON_GetObjectItemCaseSensitive(j.get(),"qpos"),11,cJSON_CreateNumber(value));reject(j.get());}
    {auto j=valid();cJSON_ReplaceItemInArray(cJSON_GetObjectItemCaseSensitive(j.get(),"qpos"),71,cJSON_CreateString("1"));reject(j.get());}
    for(auto name:{"snapshotTick","generation"})for(auto value:{-1.0,.5,9007199254740992.0,std::numeric_limits<double>::infinity()}){
        auto j=valid();cJSON_AddNumberToObject(j.get(),name,value);reject(j.get());}
    for(auto name:{"snapshotTick","generation"}){auto j=valid();cJSON_AddStringToObject(j.get(),name,"12");reject(j.get());}
    {auto j=valid();cJSON_AddBoolToObject(j.get(),"extra",true);auto before=cJSON_PrintUnformatted(j.get());rek_eval::frame_request(j.get());auto after=cJSON_PrintUnformatted(j.get());assert(!std::strcmp(before,after));cJSON_free(before);cJSON_free(after);checks++;}
    std::cout<<"{\"checks\":"<<checks<<",\"failures\":0,\"render_or_cuda_executed\":false}\n";
}
