# Playback worker candidate

This package contains the freshly linked Linux ARM64 / CUDA SM121 evaluator, the complete selected source snapshot, a delta against the preserved worker, and 97 passing CPU request-parser checks. Runtime performance and trajectory comparison are pending separately. No runtime success is implied by this build receipt.

The new `--render-only --config FILE` process accepts only `frame` requests with exactly 72 finite qpos numbers and optional nonnegative safe-integer `snapshotTick` and `generation` fields, which it echoes. It constructs the MuJoCo/EGL renderer without constructing the native simulation or controller. The normal worker caches reporting snapshots after each reset, policy reset and successful step; explicit snapshot requests refresh them. Physics, timestep and motor code are unchanged.

The binary requires the same pinned external assets, models, CUDA, MuJoCo and runtime catalog as the original native-clone release. This is a runnable replacement executable with external dependencies, not a self-contained distribution. `build-r1/reused-inputs.sha256` records linked object provenance. `build-worker.sh` relinks from the preserved Spark build-r6 inputs after hash checks; it does not execute the binary. The repository's full native build tool also recompiles the worker and new header.

CUDA graph replay stays disabled. Benchmark and final adoption are separate parent-controlled steps.
